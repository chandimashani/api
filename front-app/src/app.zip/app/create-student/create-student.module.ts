export class Student{
    st_name:any;
    st_DOB:any;
    st_Sex:any;
    st_Addresss:any;
}