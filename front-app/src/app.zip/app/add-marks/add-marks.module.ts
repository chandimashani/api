export class Marks{
    st_Number:any;
    sb_code:any;
    Term_no:any;
    mark:any;
    year:any;
}